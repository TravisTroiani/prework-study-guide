# prework-study-guide
a study guide for course pre-work
